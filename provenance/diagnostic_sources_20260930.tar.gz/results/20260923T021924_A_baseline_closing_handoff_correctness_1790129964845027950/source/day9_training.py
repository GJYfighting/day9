"""Fresh SAC training with explicit physical-transition accounting.

The manual one-step collector uses SB3 policy scaling, ReplayBuffer and SAC.train.
It avoids Gym reset failures discarding the terminal transition during autoreset.
"""
from __future__ import annotations
import copy
import hashlib
import json
from pathlib import Path
import pickle
import random
import signal
import time

import numpy as np
import torch
from stable_baselines3 import SAC
from stable_baselines3.common.logger import configure
from day9_env import ROOT, Day9Env, Trace, clean, local, write_json, pause_simulation
from day8_env import TechnicalFailure


def add_transition(model, obs, action, next_obs, reward, terminated, truncated):
    scaled=model.policy.scale_action(np.asarray(action,np.float32))
    if not np.isfinite(scaled).all() or np.any(np.abs(scaled)>1.000001):
        raise ValueError('invalid scaled replay action')
    model.replay_buffer.add(np.asarray(obs,np.float32)[None],np.asarray(next_obs,np.float32)[None],
        scaled[None],np.array([reward],np.float32),np.array([terminated or truncated],np.float32),
        [dict(TimeLimit_truncated=truncated and not terminated, **{'TimeLimit.truncated':truncated and not terminated})])


def update_probe():
    from run_day9 import new_model, SpaceOnly, model_hash, budget_state, hash_file, consume_budget
    b=budget_state()
    if b.get('probe_updates',0):raise RuntimeError('Probe budget already used; retain existing evidence')
    declaration=dict(purpose='isolated optimizer/replay/save-load interface probe; not pilot learning',
        environment_steps=0,updates_per_method=10,total_updates=20,batch_size=128,
        sampling='SB3 replacement sampling from measured real transitions; small buffer explicitly allowed for this interface check',
        paired_models_mutated=False,seed=20260908,wall_limit_sec=180,
        stop='nonfinite loss/parameters, missing real data, any budget exceeded')
    write_json('results/update_probe_declaration.json',declaration)
    print(json.dumps(declaration),flush=True)
    deadline=min(time.monotonic()+180,b['stop_measurement_monotonic']);results=[]
    for method in ['B','F']:
        records=[];sources=[]
        for p in sorted((ROOT/'results').glob(f'*_{method}_*/events.jsonl')):
            rows=[json.loads(s) for s in p.read_text().splitlines()]
            values=[r for r in rows if r['kind']=='transition']
            if values:records.extend(values);sources.append(dict(path=str(p.relative_to(ROOT)),sha256=hash_file(p)))
        if not records:raise RuntimeError('No real transitions for '+method)
        model=new_model(SpaceOnly(),20260908)
        model.set_logger(configure(str(ROOT/f'results/update_probe_{method}'),['csv']))
        for r in records:add_transition(model,r['observation'],r['policy_action'],r['next_observation'],r['reward'],r['terminated'],r['truncated'])
        before=model_hash(model);start=time.monotonic()
        losses=[]
        for _ in range(10):
            if time.monotonic()>=deadline:raise TechnicalFailure('probe wall budget exceeded')
            model.train(gradient_steps=1,batch_size=128)
            stats=dict(model.logger.name_to_value)
            if any(not np.isfinite(float(v)) for v in stats.values() if isinstance(v,(float,int))):
                raise TechnicalFailure('nonfinite probe metrics')
            if any(not torch.isfinite(p).all() for p in model.policy.parameters()):raise TechnicalFailure('nonfinite probe weights')
            losses.append(clean(stats));model.logger.dump(step=model._n_updates)
            consume_budget('probe')
        elapsed=time.monotonic()-start
        path=ROOT/f'models/diagnostic/probe_{method}.zip';model.save(path)
        replay=ROOT/f'models/diagnostic/probe_{method}_replay.pkl';model.save_replay_buffer(replay)
        loaded=SAC.load(path,device='cpu');loaded.load_replay_buffer(replay)
        result=dict(method=method,real_transitions=len(records),sources=sources,updates=model._n_updates,
            weights_changed=before!=model_hash(model),saved_loaded_equal=model_hash(model)==model_hash(loaded),
            replay_count=loaded.replay_buffer.size(),wall_sec=elapsed,wall_sec_per_update=elapsed/10,
            metrics=losses,training_steps=0)
        if not result['weights_changed'] or not result['saved_loaded_equal']:raise AssertionError('probe update/roundtrip failed')
        results.append(result);write_json('results/update_probe.json',dict(status='PASS' if len(results)==2 else 'PARTIAL',results=results))
    print(json.dumps(clean(results),indent=2))


def checkpoint(model, env, directory, status, counters):
    directory=local(directory);directory.mkdir(parents=True,exist_ok=True)
    label=f'step_{model.num_timesteps:06d}_{time.time_ns()}'
    model_path=directory/(label+'.zip');replay_path=directory/(label+'_replay.pkl')
    start=time.monotonic();model.save(model_path);model.save_replay_buffer(replay_path)
    random_state=dict(python=random.getstate(),numpy=np.random.get_state(),torch=torch.get_rng_state(),
                      action_space=env.action_space.np_random.bit_generator.state)
    rng_path=directory/(label+'_rng.pkl')
    with rng_path.open('xb') as stream:pickle.dump(random_state,stream)
    state=dict(status=status,steps=model.num_timesteps,updates=model._n_updates,
        model=str(model_path.relative_to(ROOT)),replay=str(replay_path.relative_to(ROOT)),
        rng=str(rng_path.relative_to(ROOT)),curriculum=env.manager.state(),next_attempt=env.attempt,
        counters=counters,resume_semantics='continue optimizer/replay/RNG/curriculum at a new safely reset physical episode; not bitwise simulator continuation')
    write_json(directory/'latest.json',state)
    env.trace.emit('checkpoint',state=state,wall_sec=time.monotonic()-start)
    return state


def train_one(method, config, seed, steps, wall_limit, *, stage, initial=None):
    from run_day9 import new_model, resolved_model, code_hashes, model_hash, technical_error
    config=local(config);c=__import__('yaml').safe_load(config.read_text())
    run=f'{time.strftime("%Y%m%dT%H%M%S",time.gmtime())}_{method}_{stage}_{seed}_{time.time_ns()}'
    trace=Trace(run);env=None;model=None;start=time.monotonic();deadline=start+wall_limit
    counters=dict(complete_episodes=0,successes=0,grasp_attempts=0,reset_failures=0,technical_failures=0)
    status='RUNNING';error=None;saved=None;initial_hash=None
    declaration=dict(purpose=stage,method=method,seed=seed,steps=steps,wall_limit_sec=wall_limit,
        config=c,code_hashes=code_hashes(),fresh=initial is None,initial=initial,
        max_task_reset_failures_consecutive=20,max_scene_attempts=2*steps,max_technical_retries=1,
        validation_steps=0,update_budget=max(0,steps-1000),checkpoint_every_steps=1000)
    write_json(f'results/{run}/declaration.json',declaration);print(json.dumps(declaration),flush=True)
    def stop(*_):raise TechnicalFailure('training interrupted or declared wall deadline reached')
    handlers={s:signal.signal(s,stop) for s in [signal.SIGALRM,signal.SIGINT,signal.SIGTERM]}
    signal.setitimer(signal.ITIMER_REAL,max(.01,wall_limit-120))
    try:
        env=Day9Env(method,config,trace,phase='train',profile=c['day9']['profile'],seed=seed)
        model=new_model(env,seed)
        model.set_logger(configure(str(ROOT/f'results/{run}/sac'),['csv']))
        if initial is not None:
            state=json.loads(local(initial).read_text())
            model=SAC.load(local(state['model']),env=env,device='cpu')
            model.load_replay_buffer(local(state['replay']))
            model.set_logger(configure(str(ROOT/f'results/{run}/sac'),['csv']))
            with local(state['rng']).open('rb') as stream:rng=pickle.load(stream)
            random.setstate(rng['python']);np.random.set_state(rng['numpy']);torch.set_rng_state(rng['torch'])
            env.action_space.np_random.bit_generator.state=rng['action_space']
            env.manager.restore(state['curriculum']);env.attempt=state['next_attempt'];counters=state['counters']
        initial_hash=model_hash(model)
        write_json(f'results/{run}/resolved.json',resolved_model(model))
        obs=None;reset_streak=0;technical_retries=0
        while model.num_timesteps<steps:
            if time.monotonic()>=deadline-120:raise TechnicalFailure('training wall budget reached')
            if env.attempt>=2*steps:raise TechnicalFailure('scene attempt budget reached')
            if obs is None:
                try:
                    obs,_=env.reset();reset_streak=0
                except Exception as exc:
                    counters['reset_failures']+=1;reset_streak+=1
                    ok,detail=env.base.backend.safe_recover()
                    if not ok:raise TechnicalFailure('reset recovery failed: '+detail) from exc
                    if technical_error(exc):
                        counters['technical_failures']+=1
                        if technical_retries>=1:raise
                        technical_retries+=1;env.attempt-=1
                    elif reset_streak>=20:raise TechnicalFailure('20 consecutive task initialization failures') from exc
                    continue
            with trace.span('inference'):
                action=env.action_space.sample() if model.num_timesteps<model.learning_starts else model.predict(obs,deterministic=False)[0]
            next_obs,reward,terminated,truncated,info=env.step(action)
            add_transition(model,obs,action,next_obs,reward,terminated,truncated)
            model.num_timesteps+=1
            model._total_timesteps=steps
            model._current_progress_remaining=1-model.num_timesteps/steps
            counters['grasp_attempts']+=int(info['grasp_attempted'])
            if model.num_timesteps>model.learning_starts:
                with trace.span('network_update'):model.train(gradient_steps=1,batch_size=128)
                metrics=dict(model.logger.name_to_value)
                if any(not np.isfinite(float(v)) for v in metrics.values() if isinstance(v,(float,int))):
                    raise TechnicalFailure('nonfinite SAC training metrics')
                if any(not torch.isfinite(p).all() for p in model.policy.parameters()):raise TechnicalFailure('nonfinite network')
                trace.emit('network_update',steps=model.num_timesteps,updates=model._n_updates,metrics=metrics)
                model.logger.dump(step=model.num_timesteps)
            if terminated or truncated:
                counters['complete_episodes']+=1;counters['successes']+=int(info['success']);obs=None
            else:obs=next_obs
            if model.num_timesteps%1000==0:
                with trace.span('checkpoint_write'):saved=checkpoint(model,env,f'models/{stage}/{method}_{seed}','RUNNING',counters)
        status='COMPLETE'
    except BaseException as exc:
        error=f'{type(exc).__name__}: {exc}';status='INTERRUPTED';trace.emit('training_exception',error=error)
    finally:
        signal.setitimer(signal.ITIMER_REAL,0)
        if model is not None and env is not None:
            try:saved=checkpoint(model,env,f'models/{stage}/{method}_{seed}',status,counters)
            except Exception as exc:trace.emit('checkpoint_failure',error=repr(exc));status='CHECKPOINT_FAILED'
        if env is not None:
            signal.setitimer(signal.ITIMER_REAL,max(.01,min(120,deadline-time.monotonic())))
            try:env.close()
            except BaseException as exc:
                trace.emit('close_failure',error=repr(exc));status='RECOVERY_FAILED'
                try:pause_simulation()
                except Exception:pass
        signal.setitimer(signal.ITIMER_REAL,0)
        for s,h in handlers.items():signal.signal(s,h)
        report=dict(run=run,status=status,error=error,method=method,seed=seed,
            steps=0 if model is None else model.num_timesteps,updates=0 if model is None else model._n_updates,
            counters=counters,wall_sec=time.monotonic()-start,timings=trace.snapshot(),checkpoint=saved,
            weights_changed=model is not None and initial_hash is not None and model_hash(model)!=initial_hash,
            includes=['startup','reset','randomization','grasp','network_update','checkpoint','safe_close'])
        write_json(f'results/{run}/training_summary.json',report);trace.close()
    return report
